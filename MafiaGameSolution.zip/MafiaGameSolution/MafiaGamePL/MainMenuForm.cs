﻿using System;
using System.Windows.Forms;

namespace MafiaGamePL
{
    public class MainMenuForm : Form
    {
        private Button btnStartGame;
        private Button btnExit;

        public MainMenuForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.btnStartGame = new Button();
            this.btnExit = new Button();

            this.btnStartGame.Text = "Start Game";
            this.btnStartGame.Location = new System.Drawing.Point(100, 50);
            this.btnStartGame.Size = new System.Drawing.Size(100, 30);
            this.btnStartGame.Click += new EventHandler(this.BtnStartGame_Click);

            this.btnExit.Text = "Exit";
            this.btnExit.Location = new System.Drawing.Point(100, 100);
            this.btnExit.Size = new System.Drawing.Size(100, 30);
            this.btnExit.Click += new EventHandler(this.BtnExit_Click);

            this.ClientSize = new System.Drawing.Size(300, 200);
            this.Controls.Add(this.btnStartGame);
            this.Controls.Add(this.btnExit);
            this.Text = "Main Menu";
        }

        private void BtnStartGame_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Game started!");
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}